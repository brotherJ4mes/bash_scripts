addpath(genpath('Tests'));

TestSanity 

TestEleSizes

TestJBAY

TestECGC 

exit
