function [] = link 

figure(1); ax1=gca; 
figure(2); ax2=gca; 
linkaxes([ax1,ax2],'xy'); 